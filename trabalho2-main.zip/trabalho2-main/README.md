# 2º trabalho desenvolvimento web<br/> Disciplina da ufc-campus russas.<br/>
### Explicação : <br/>
O trabalho é uma api feita em @TypeScript que faz o gerenciamento de uma padaria,</br>
onde na mesma temos um CRUD no podemos fazer as operações do crud em cada uma das entidade que são:</br>
Cliente, Venda e produto.