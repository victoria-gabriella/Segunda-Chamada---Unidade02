/* eslint no-use-before-define: 0 */
import React from 'react'
import './index.css';


function Footer() {
  return (
    <div className='Footer'>
    </div>
  )
}

export default Footer